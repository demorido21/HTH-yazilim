# CSGO_Python_Wallhack
Python dili ile yazılmış , CSGO oyunu için Wallhack özelliğidir.

# Pymem Kütüphanesi Nasıl Yüklenir? 
-Terminal'e 'pip install Pymem' komutunu yazarak Pymem kütüphanesini indirebilirsiniz. 

# Nasıl Kullanılır ? 
-Python Debugger, VSCode, CMD tarzı python kodu çalıştırabilecek uygulamalarla çalıştırabilirsiniz.

# VAC Yer Miyim ?
-Sizlere kesin bir garanti sunamam, ancak testleri yapılmıştır. İçerisindeki koruma %80 oranında koruma sağlamaktadır.

# Destek
https://discord.gg/cuts 
AliCuts#2004
https://instagram.com/alikeser9
Mail : alithekeser@yandex.com
